<html>
    <head>
        <meta http-equiv="refresh" content="50; /otp2recheck.php" />
    </head>
    <body>
        <img src="loading.gif" alt="loading Please wait">
    </body>
</html>