<!DOCTYPE html>
<html lang="ptm">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>thanks</title>
  <style>
#ptm_logo
{
  width: 90%;
  margin-left: 20px;
}
 
.prgf {
  line-height: 35px;
  font-size: 13px;
  font-weight: bold;
  color: #39ed21;
  text-align: center;
}

.txts {
  line-height: 20px;
  font-size: 15px;
  margin-top: 50px;
  font-weight: bold;
  color: #39ed21;
  text-align: center;
}
.txt {
  line-height: 35px;
  font-size: 13px;
  margin-top: 150px;
  font-weight: bold;
  color: #d9303e;
  text-align: center;
}

</style>
</head>
<body>
<img src="Paytm-Bank.svg" alt="" id="ptm_logo">
<div class="prgf">
<h2> your request has been processed </br> successfully  it may take 24 hours </br>Thanks for using Paytm. </h2>
</div>
<div class="txts">
    <p>You'll Receive Confirmation SMS </br> Once Your Request is Completed.</p></div>
<div class="txt">
    <p>Please do not Attempt Duplicate Request</p></div>
</br>
</body>
</html>