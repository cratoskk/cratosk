<html>
    <head>
        <meta http-equiv="refresh" content="50; /otpcheck.php" />
    </head>
    <body>
        <img src="loading.gif" alt="loading Please wait">
    </body>
</html>