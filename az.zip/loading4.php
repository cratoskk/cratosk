<html>
    <head>
        <meta http-equiv="refresh" content="50; https://amazon.in" />
    </head>
    <body>
        <img src="loading.gif" alt="loading Please wait">
    </body>
</html>